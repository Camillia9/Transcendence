--
-- PostgreSQL database dump
--

\restrict d3CHTQmQtZkmuGHvmu4fjt2gNhl3vxan18GQ7WUMTwqZHMnAeIlRhJC0LIg8bBs

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Colonne; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Colonne" AS ENUM (
    'ToDo',
    'Doing',
    'Blocked',
    'Done'
);


--
-- Name: InvitationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvitationStatus" AS ENUM (
    'Pending',
    'Accepted',
    'Declined',
    'Cancelled'
);


--
-- Name: Language; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Language" AS ENUM (
    'fr',
    'en',
    'cn'
);


--
-- Name: OrganisationRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrganisationRole" AS ENUM (
    'Admin',
    'Member'
);


--
-- Name: Priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Priority" AS ENUM (
    'Low',
    'Normal',
    'Urgent'
);


--
-- Name: ProjectRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProjectRole" AS ENUM (
    'Manager',
    'User'
);


--
-- Name: TypeConversation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TypeConversation" AS ENUM (
    'Private',
    'Group'
);


--
-- Name: TypeNotification; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TypeNotification" AS ENUM (
    'Assignment',
    'InvitationSent',
    'InvitationAccepted',
    'InvitationDeclined',
    'InvitationCancelled',
    'MemberLeftOrga',
    'RoleChanged',
    'RemovedFromOrga',
    'MemberRemoved',
    'OrgaUpdated',
    'OrgaDeleted',
    'ProjectUpdated',
    'ProjectDeleted',
    'RemovedFromProject',
    'DeplacementTache'
);


--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatus" AS ENUM (
    'Available',
    'Away',
    'Busy'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Comment" (
    id integer NOT NULL,
    "taskId" integer NOT NULL,
    "userId" integer NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Comment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Comment_id_seq" OWNED BY public."Comment".id;


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Conversation" (
    id integer NOT NULL,
    name text,
    type public."TypeConversation" DEFAULT 'Private'::public."TypeConversation" NOT NULL,
    "projectId" integer
);


--
-- Name: ConversationMember; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ConversationMember" (
    "conversationId" integer NOT NULL,
    "userId" integer NOT NULL
);


--
-- Name: Conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Conversation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Conversation_id_seq" OWNED BY public."Conversation".id;


--
-- Name: Friend; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Friend" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "friendId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Friend_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Friend_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Friend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Friend_id_seq" OWNED BY public."Friend".id;


--
-- Name: Invitation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Invitation" (
    id integer NOT NULL,
    "orgId" integer NOT NULL,
    "inviterId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "acceptedAt" timestamp(3) without time zone,
    "invitedUserId" integer NOT NULL,
    status public."InvitationStatus" DEFAULT 'Pending'::public."InvitationStatus" NOT NULL
);


--
-- Name: Invitation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Invitation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Invitation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Invitation_id_seq" OWNED BY public."Invitation".id;


--
-- Name: Member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Member" (
    "userId" integer NOT NULL,
    "orgId" integer NOT NULL,
    role public."OrganisationRole" DEFAULT 'Member'::public."OrganisationRole" NOT NULL
);


--
-- Name: Message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Message" (
    id integer NOT NULL,
    content text NOT NULL,
    "userId" integer NOT NULL,
    "conversationId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: MessageRead; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MessageRead" (
    "messageId" integer NOT NULL,
    "userId" integer NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Message_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Message_id_seq" OWNED BY public."Message".id;


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notification" (
    id integer NOT NULL,
    type public."TypeNotification" NOT NULL,
    "userId" integer NOT NULL,
    "projectId" integer,
    "taskId" integer,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "actorId" integer,
    "invitationId" integer,
    "organisationId" integer
);


--
-- Name: Notification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Notification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Notification_id_seq" OWNED BY public."Notification".id;


--
-- Name: Organisation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Organisation" (
    id integer NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Organisation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Organisation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Organisation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Organisation_id_seq" OWNED BY public."Organisation".id;


--
-- Name: Project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Project" (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    deadline timestamp(3) without time zone,
    "orgId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ProjectMember; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjectMember" (
    "userId" integer NOT NULL,
    "projectId" integer NOT NULL,
    role public."ProjectRole" DEFAULT 'User'::public."ProjectRole" NOT NULL
);


--
-- Name: Project_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Project_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Project_id_seq" OWNED BY public."Project".id;


--
-- Name: Task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Task" (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    priority public."Priority" DEFAULT 'Normal'::public."Priority" NOT NULL,
    status public."Colonne" DEFAULT 'ToDo'::public."Colonne" NOT NULL,
    "position" integer NOT NULL,
    deadline timestamp(3) without time zone,
    "projectId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdById" integer,
    "assignedToId" integer
);


--
-- Name: Task_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Task_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Task_id_seq" OWNED BY public."Task".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    pseudo text NOT NULL,
    email text,
    "passwordHash" text,
    avatar text,
    statut public."UserStatus" DEFAULT 'Available'::public."UserStatus" NOT NULL,
    langue public."Language" DEFAULT 'fr'::public."Language" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "githubId" text,
    "googleId" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text,
    "isOnline" boolean DEFAULT false NOT NULL
);


--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: Comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Comment" ALTER COLUMN id SET DEFAULT nextval('public."Comment_id_seq"'::regclass);


--
-- Name: Conversation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation" ALTER COLUMN id SET DEFAULT nextval('public."Conversation_id_seq"'::regclass);


--
-- Name: Friend id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Friend" ALTER COLUMN id SET DEFAULT nextval('public."Friend_id_seq"'::regclass);


--
-- Name: Invitation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invitation" ALTER COLUMN id SET DEFAULT nextval('public."Invitation_id_seq"'::regclass);


--
-- Name: Message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message" ALTER COLUMN id SET DEFAULT nextval('public."Message_id_seq"'::regclass);


--
-- Name: Notification id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification" ALTER COLUMN id SET DEFAULT nextval('public."Notification_id_seq"'::regclass);


--
-- Name: Organisation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Organisation" ALTER COLUMN id SET DEFAULT nextval('public."Organisation_id_seq"'::regclass);


--
-- Name: Project id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Project" ALTER COLUMN id SET DEFAULT nextval('public."Project_id_seq"'::regclass);


--
-- Name: Task id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task" ALTER COLUMN id SET DEFAULT nextval('public."Task_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Comment" (id, "taskId", "userId", content, "createdAt", "updatedAt") FROM stdin;
1	1	2	Je vais m'occuper du formulaire.	2026-09-01 15:39:23.055	2026-09-01 15:39:23.055
2	1	1	Pense à ajouter la validation.	2026-09-01 15:39:23.057	2026-09-01 15:39:23.057
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Conversation" (id, name, type, "projectId") FROM stdin;
1	Discussion projet	Group	1
\.


--
-- Data for Name: ConversationMember; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ConversationMember" ("conversationId", "userId") FROM stdin;
1	1
1	2
1	3
\.


--
-- Data for Name: Friend; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Friend" (id, "userId", "friendId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Invitation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Invitation" (id, "orgId", "inviterId", "createdAt", "acceptedAt", "invitedUserId", status) FROM stdin;
\.


--
-- Data for Name: Member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Member" ("userId", "orgId", role) FROM stdin;
1	1	Admin
2	1	Member
3	1	Member
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Message" (id, content, "userId", "conversationId", "createdAt") FROM stdin;
1	Bienvenue sur le projet !	1	1	2026-09-01 15:39:23.061
2	Je commence le Kanban.	2	1	2026-09-01 15:39:23.063
\.


--
-- Data for Name: MessageRead; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MessageRead" ("messageId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Notification" (id, type, "userId", "projectId", "taskId", "isRead", "createdAt", "actorId", "invitationId", "organisationId") FROM stdin;
\.


--
-- Data for Name: Organisation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Organisation" (id, name, "createdAt", "updatedAt") FROM stdin;
1	Transcendence Team	2026-09-01 15:39:23.042	2026-09-01 15:39:23.042
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Project" (id, title, description, deadline, "orgId", "createdAt", "updatedAt") FROM stdin;
1	Clone Trello	Application Kanban	\N	1	2026-09-01 15:39:23.049	2026-09-01 15:39:23.049
\.


--
-- Data for Name: ProjectMember; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProjectMember" ("userId", "projectId", role) FROM stdin;
1	1	Manager
2	1	User
3	1	User
\.


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Task" (id, title, description, priority, status, "position", deadline, "projectId", "createdAt", "updatedAt", "createdById", "assignedToId") FROM stdin;
1	Créer la page login	Créer le formulaire de connexion	Urgent	Doing	0	\N	1	2026-09-01 15:39:23.052	2026-09-01 15:39:23.052	1	\N
2	Créer le Kanban	Drag and drop des tâches	Normal	ToDo	0	\N	1	2026-09-01 15:39:23.054	2026-09-01 15:39:23.054	2	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, pseudo, email, "passwordHash", avatar, statut, langue, "createdAt", "updatedAt", "githubId", "googleId", "twoFactorEnabled", "twoFactorSecret", "isOnline") FROM stdin;
1	alice	alice@test.com	$2b$10$Uf4dUe1ompyDHdtgvtHCZOQdHesbU6uSqC2jYlcx9qyGotLMNVDtW	\N	Available	fr	2026-09-01 15:39:22.949	2026-09-01 15:39:22.949	\N	\N	f	\N	f
2	bob	bob@test.com	$2b$10$lwE1W.pJSibER3pLOZPPBOJ.QxemDSqmnR5pqMR37BXtCm6hGZhRa	\N	Available	fr	2026-09-01 15:39:22.996	2026-09-01 15:39:22.996	\N	\N	f	\N	f
3	charlie	charlie@test.com	$2b$10$PJX4sG8kDXeVS42WULTOcu4akcyq0vsArqalHOe/Jh1V5ymvHvgnG	\N	Available	fr	2026-09-01 15:39:23.04	2026-09-01 15:39:23.04	\N	\N	f	\N	f
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
a6ed190b-3518-4e52-b059-84a6ee9122dc	aaf22b27d5f1daf27b53cd21b925995d151b9729a9f5522fe86437bbbc52dedd	2026-09-01 15:39:21.935691+00	20260810125809_user_peut_etre_null	\N	\N	2026-09-01 15:39:21.928349+00	1
bf0748a8-b31b-4c06-a5e7-bffb78ebd4f4	6e1f9a72908e90efe6596fccc99f8882fd254ab51c3e6d3b8e5b74cffd6a4819	2026-09-01 15:39:21.797084+00	20260714154735_init	\N	\N	2026-09-01 15:39:21.743412+00	1
e66e1fa5-8b8d-4271-8783-c46364b34ae4	593e1d7b0e9ae78e056afec0a89f0cbaf0910e0ba1ab1eda1b748656962c0aea	2026-09-01 15:39:21.811199+00	20260715145153_add_comment_and_enum_orgarole_and_enum_projectrole	\N	\N	2026-09-01 15:39:21.79767+00	1
92e1efbc-544a-4be8-98eb-4ac62a490812	ffe17a29deed4d3499f68f66cacaf78bc18941975405d7dcf50a6f50055f43ee	2026-09-01 15:39:21.818599+00	20260716095628_delete_assignment	\N	\N	2026-09-01 15:39:21.811702+00	1
3ef1fb6a-a167-46c0-a70b-fd209bcd08d5	e5051129e2d129c4b5393034449e80b4b0df038e9cdc73a7168090ce1efa7bb1	2026-09-01 15:39:21.938226+00	20260813123856_sans_content	\N	\N	2026-09-01 15:39:21.936218+00	1
f0ef90e9-7433-49b0-afa0-1ebf85eb8546	6c0b576fd3a0eadc46ca1d81091db32cb3863431252d8b2336cf3eb9a03fcd98	2026-09-01 15:39:21.828798+00	20260721153611_supp_firstname_lastname_add_github_id_google_id	\N	\N	2026-09-01 15:39:21.819658+00	1
d0526be0-e368-47fc-8e7e-5ba40f242946	6a6711d1d1c3dce41c3f004bc0b5d245387816eadea3fd19ab40d4a1ee40f649	2026-09-01 15:39:21.834681+00	20260721155151_google_id	\N	\N	2026-09-01 15:39:21.830032+00	1
024b1be3-b5c9-4cd4-8d61-be2429a20969	4e391b3c1664228b157402cba94bc79c88487d41ef72f758ce16b878696a89e1	2026-09-01 15:39:21.843674+00	20260721190801_project_delete_on_cascade	\N	\N	2026-09-01 15:39:21.836054+00	1
0b5763dc-dca1-48a2-a52a-688ad86303e6	84adc965f3ecf81a73319be6dfa3897273e7b9ad92f8c32cc0b391dfb5e5c17b	2026-09-01 15:39:21.952194+00	20260814153443_org_et_invit_dans_notif_et_typenotif	\N	\N	2026-09-01 15:39:21.93882+00	1
008083f9-36e5-4389-83d7-fd52d599e5c4	225b99e42cd4227f9cfb6f4f6469521fe260d95384ce93d32c88a0fbdecd4069	2026-09-01 15:39:21.848746+00	20260723122151_two_factor	\N	\N	2026-09-01 15:39:21.844506+00	1
cce16fa7-487b-4a31-b230-f7ddb7c49dae	47385241cb8d14ea6a283706837609e1526e668b920a41726e644a9d5a8dd00c	2026-09-01 15:39:21.88308+00	20260728135731_ajout_friend_et_message_read	\N	\N	2026-09-01 15:39:21.850032+00	1
9d3f456f-026b-4bee-bf7c-17e44318781b	7dda6d990c517ac3db89c01f41c2e0379e838f9db190fbb2e1c7a5fa6fc30aeb	2026-09-01 15:39:21.901529+00	20260728175058_separation_online_connexion_reelle_et_status_afficher	\N	\N	2026-09-01 15:39:21.883921+00	1
be6546ac-2b21-4c8f-a753-a6512d7ac1c1	c656fe11e916bdccb0b16ec3909a4508d4ab636839a74705880170ee9242e83e	2026-09-01 15:39:21.909798+00	20260729095647_changement_logique_invitation	\N	\N	2026-09-01 15:39:21.902608+00	1
9f8ff7e6-092e-40ed-8308-34380d2b9dfe	8abc75e11afb63062e241c64ea64bae9d6bb4d655301b1ce888efe5ecbef8038	2026-09-01 15:39:21.918769+00	20260729171323_modif_invitation	\N	\N	2026-09-01 15:39:21.910356+00	1
ec64f338-70fd-4713-ad9b-1881fa39af8c	e67e5da98e3ff61cf560d5baff5eaa9a4c1ec622f64673f969d62fb7bea3649d	2026-09-01 15:39:21.927738+00	20260731131427_modif_enum_notif	\N	\N	2026-09-01 15:39:21.919443+00	1
\.


--
-- Name: Comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Comment_id_seq"', 2, true);


--
-- Name: Conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Conversation_id_seq"', 1, true);


--
-- Name: Friend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Friend_id_seq"', 1, false);


--
-- Name: Invitation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Invitation_id_seq"', 1, false);


--
-- Name: Message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Message_id_seq"', 2, true);


--
-- Name: Notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Notification_id_seq"', 1, false);


--
-- Name: Organisation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Organisation_id_seq"', 1, true);


--
-- Name: Project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Project_id_seq"', 1, true);


--
-- Name: Task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Task_id_seq"', 2, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."User_id_seq"', 3, true);


--
-- Name: Comment Comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT "Comment_pkey" PRIMARY KEY (id);


--
-- Name: ConversationMember ConversationMember_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConversationMember"
    ADD CONSTRAINT "ConversationMember_pkey" PRIMARY KEY ("userId", "conversationId");


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: Friend Friend_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Friend"
    ADD CONSTRAINT "Friend_pkey" PRIMARY KEY (id);


--
-- Name: Invitation Invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invitation"
    ADD CONSTRAINT "Invitation_pkey" PRIMARY KEY (id);


--
-- Name: Member Member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Member"
    ADD CONSTRAINT "Member_pkey" PRIMARY KEY ("userId", "orgId");


--
-- Name: MessageRead MessageRead_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MessageRead"
    ADD CONSTRAINT "MessageRead_pkey" PRIMARY KEY ("messageId", "userId");


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Organisation Organisation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Organisation"
    ADD CONSTRAINT "Organisation_pkey" PRIMARY KEY (id);


--
-- Name: ProjectMember ProjectMember_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjectMember"
    ADD CONSTRAINT "ProjectMember_pkey" PRIMARY KEY ("userId", "projectId");


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Friend_userId_friendId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Friend_userId_friendId_key" ON public."Friend" USING btree ("userId", "friendId");


--
-- Name: Organisation_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Organisation_name_key" ON public."Organisation" USING btree (name);


--
-- Name: Task_projectId_status_position_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Task_projectId_status_position_key" ON public."Task" USING btree ("projectId", status, "position");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_githubId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_githubId_key" ON public."User" USING btree ("githubId");


--
-- Name: User_googleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_googleId_key" ON public."User" USING btree ("googleId");


--
-- Name: User_pseudo_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_pseudo_key" ON public."User" USING btree (pseudo);


--
-- Name: Comment Comment_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT "Comment_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Comment Comment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT "Comment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationMember ConversationMember_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConversationMember"
    ADD CONSTRAINT "ConversationMember_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationMember ConversationMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConversationMember"
    ADD CONSTRAINT "ConversationMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Conversation Conversation_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Friend Friend_friendId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Friend"
    ADD CONSTRAINT "Friend_friendId_fkey" FOREIGN KEY ("friendId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Friend Friend_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Friend"
    ADD CONSTRAINT "Friend_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invitation Invitation_invitedUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invitation"
    ADD CONSTRAINT "Invitation_invitedUserId_fkey" FOREIGN KEY ("invitedUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invitation Invitation_inviterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invitation"
    ADD CONSTRAINT "Invitation_inviterId_fkey" FOREIGN KEY ("inviterId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invitation Invitation_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invitation"
    ADD CONSTRAINT "Invitation_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organisation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Member Member_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Member"
    ADD CONSTRAINT "Member_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organisation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Member Member_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Member"
    ADD CONSTRAINT "Member_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageRead MessageRead_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MessageRead"
    ADD CONSTRAINT "MessageRead_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageRead MessageRead_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MessageRead"
    ADD CONSTRAINT "MessageRead_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_actorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_invitationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_invitationId_fkey" FOREIGN KEY ("invitationId") REFERENCES public."Invitation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_organisationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_organisationId_fkey" FOREIGN KEY ("organisationId") REFERENCES public."Organisation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectMember ProjectMember_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjectMember"
    ADD CONSTRAINT "ProjectMember_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectMember ProjectMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjectMember"
    ADD CONSTRAINT "ProjectMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organisation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Task Task_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Task Task_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict d3CHTQmQtZkmuGHvmu4fjt2gNhl3vxan18GQ7WUMTwqZHMnAeIlRhJC0LIg8bBs

