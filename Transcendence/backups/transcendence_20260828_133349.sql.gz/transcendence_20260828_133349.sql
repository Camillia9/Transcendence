--
-- PostgreSQL database dump
--

\restrict oxI3inO1hiZf1oT3QwVaD6PccJfL2lmPgXL6EsXR6Ivij3nY8c5vad7saYrY2ik

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict oxI3inO1hiZf1oT3QwVaD6PccJfL2lmPgXL6EsXR6Ivij3nY8c5vad7saYrY2ik

